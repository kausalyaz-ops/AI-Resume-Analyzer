# Resume Analyzer API

Run: uvicorn main:app --reload
